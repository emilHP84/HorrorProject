-- Windows Unity premake module
local platform = {}

platform.akName = "Windows"

function platform.GetUnityPlatformName(platformName, cfgplatforms)
    return platformName, cfgplatforms
end

function platform.setupTargetAndLibDir(baseTargetDir)
    libdirs(wwiseSDKEnv .. "/%{cfg.platform}" .. GetSuffixFromCurrentAction() .. "/%{cfg.buildcfg}(StaticCRT)/lib")
end

function platform.platformSpecificConfiguration()
    links {
        "dxguid"
    }

    filter "Debug* or Profile*"
        links { "ws2_32" }
end

return platform